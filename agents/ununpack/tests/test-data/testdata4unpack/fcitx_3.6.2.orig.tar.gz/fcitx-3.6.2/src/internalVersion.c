#ifndef INT8
#define INT8 char
#endif

INT8            iInternalVersion = 0x03;
