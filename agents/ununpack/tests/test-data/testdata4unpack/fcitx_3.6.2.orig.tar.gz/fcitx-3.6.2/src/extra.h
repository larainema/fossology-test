#ifndef _EXTRA_H_
#define _EXTRA_H_

#include "ime.h"
#include "fcitx.h"

void LoadExtraIM(char *);

#endif/*_EXTRA_H_*/

