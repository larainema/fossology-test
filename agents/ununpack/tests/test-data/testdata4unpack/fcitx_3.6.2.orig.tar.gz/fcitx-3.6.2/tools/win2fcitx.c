/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * ��windows���뷨���������ɵ��ı��ļ�ת��ΪС������뷨�Ĵʿ�
 * windows���ɵ��ı��ļ���ʽ���£�
 *  ���� ���� ���� ...
 * ���ֺͱ�������û�пո񣬶��������ǿո� 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main (int argc, char *argv[])
{
    FILE           *fp;
    char            str[100];
    char            strHZ[50];
    char            strCode[50];
    char           *pstr;
    int             i, s;

    if (argc != 2) {
	fprintf (stderr, "Usage: %s <WIN Phrase File>\n", argv[0]);
	exit (-1);
    }

    fp = fopen (argv[1], "rt");
    if (!fp) {
	fprintf (stderr, "Can't open file %s\n", argv[1]);
	exit (1);
    }

    s = 0;
    for (;;) {
	if (!fgets (str, 100, fp))
	    break;

	i = strlen (str) - 1;
	while ((i >= 0) && (str[i] == ' ' || str[i] == '\n' || str[i] == '\r'))
	    str[i--] = '\0';

	pstr = str;
	if (*pstr == ' ')
	    pstr++;

	i = 0;
	while (*pstr) {
	    if (!isalpha (*pstr)) {	//�Ǻ���
		strHZ[i++] = *pstr++;
		strHZ[i] = *pstr;
	    }
	    else {		//���ֽ���
		strHZ[i] = '\0';
		break;
	    }
	    pstr++;
	    i++;
	}

	if (*pstr == ' ')
	    pstr++;
	i = 0;
	for (;;) {
	    if (*pstr != ' ' && *pstr != '\0')
		strCode[i++] = *pstr++;
	    else {
		s++;
		strCode[i] = '\0';
		printf ("%s %s\n", strCode, strHZ);

		if (!*pstr)
		    break;

		i = 0;
		pstr++;
	    }
	}
    }

    fclose (fp);

    fprintf (stderr, "Total: %d\n", s);

    return 0;
}
